package sheet2;


public class Main {

	public static void main(String[] args) {
		System.out.println("Hello, Maven!");
	}

	static boolean isEven(int x) {
		return x % 2 == 0;
	}

}
