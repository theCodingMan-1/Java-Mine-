package sheet2;

public class Fruit extends Food {

	//TODO:

}
