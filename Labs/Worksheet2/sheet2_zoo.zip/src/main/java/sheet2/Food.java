package sheet2;

public class Food {

	public String eaten(Animal animal) {
		return "animal eats food";
	}

}
