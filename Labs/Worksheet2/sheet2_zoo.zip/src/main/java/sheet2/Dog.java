package sheet2;

public class Dog extends Animal {

	//TODO:

}
