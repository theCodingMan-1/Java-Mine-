package sheet2;

public class Cat extends Animal {

	//TODO:

}
