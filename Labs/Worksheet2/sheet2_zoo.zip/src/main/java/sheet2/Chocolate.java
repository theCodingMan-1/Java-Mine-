package sheet2;

public class Chocolate extends Food {

	//TODO:

}
